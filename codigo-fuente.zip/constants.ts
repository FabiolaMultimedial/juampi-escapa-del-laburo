import {SpriteConfig} from './utils/helper';

/**
 * Visual Theme settings enforcing authentic 80s arcade neon aesthetics
 */
export const THEME = {
  fontFamily: "'Press Start 2P', monospace, system-ui",
  backgroundColor: '#030712',
  wallColor: '#0055ff',
  wallGlow: '#00e5ff',
  wallInner: '#001a40',
  mateGlow: '#22c55e',
  thermosGlow: '#ef4444',
  textPrimary: '#fbbf24',
  textSecondary: '#38bdf8',
  accentPink: '#f43f5e',
  hudBg: 'rgba(15, 23, 42, 0.95)',
  buttonPrimary: '#3b82f6',
  buttonSuccess: '#10b981',
};

/**
 * Configuration for the game.
 */
export const CONFIG = {
  // --- Game Baseline ---
  title: {
    value: 'Ayuda a Juampi a escapar del laburo',
    type: 'string',
    label: 'Game Title',
    group: 'GAME',
  },
  baseCanvasWidth: {
    value: 756,
    type: 'number',
    label: 'Base Canvas Width',
    group: 'GAME',
  },
  baseCanvasHeight: {
    value: 864,
    type: 'number',
    label: 'Base Canvas Height',
    group: 'GAME',
  },

  // --- System ---
  targetFPS: {
    value: 60,
    type: 'number',
    label: 'Target FPS',
    group: 'SYSTEM',
  },
  stepMs: {
    value: 1000 / 60,
    type: 'number',
    label: 'Step MS',
    group: 'SYSTEM',
  },
  maxSubSteps: {
    value: 5,
    type: 'number',
    label: 'Max Sub Steps',
    group: 'SYSTEM',
  },

  // --- Theme ---
  backgroundColor: {
    value: '#030712',
    type: 'color',
    label: 'Background Color',
    group: 'THEME',
  },
  primaryColor: {
    value: '#0055ff',
    type: 'color',
    label: 'Primary Color',
    group: 'THEME',
  },
  fontFamily: {
    value: "'Press Start 2P', monospace",
    type: 'string',
    label: 'Font Family',
    group: 'THEME',
  },

  // --- Audio ---
  defaultMusicVolume: {
    value: 0.5,
    type: 'number',
    label: 'Default Music Volume',
    group: 'AUDIO',
  },
  defaultSfxVolume: {
    value: 0.6,
    type: 'number',
    label: 'Default SFX Volume',
    group: 'AUDIO',
  },

  // --- Gameplay Rules (Tunable in Playground) ---
  playerSpeed: {
    value: 145,
    type: 'number',
    label: 'Player Speed',
    group: 'Rules',
  },
  enemyNormalSpeed: {
    value: 125,
    type: 'number',
    label: 'Enemy Normal Speed',
    group: 'Rules',
  },
  enemyVulnerableSpeed: {
    value: 75,
    type: 'number',
    label: 'Enemy Vulnerable Speed',
    group: 'Rules',
  },
  thermosDuration: {
    value: 8,
    type: 'number',
    label: 'Thermos Power Duration (s)',
    group: 'Rules',
  },
  startingLives: {
    value: 3,
    type: 'number',
    label: 'Starting Lives',
    group: 'Rules',
  },
  matePoints: {
    value: 10,
    type: 'number',
    label: 'Points per Mate',
    group: 'Rules',
  },
  thermosPoints: {
    value: 50,
    type: 'number',
    label: 'Points per Thermos',
    group: 'Rules',
  },

  // --- Assets Resolutions & Aspect Ratios ---
  assetHeadAspectRatio: {
    value: 0.7476,
    type: 'number',
    label: 'Protagonist Head Aspect Ratio',
    group: 'ASSETS',
  },
  assetHeadEatAspectRatio: {
    value: 0.8673,
    type: 'number',
    label: 'Protagonist Head Eat Aspect Ratio',
    group: 'ASSETS',
  },
  assetHeadDefeatAspectRatio: {
    value: 0.7830,
    type: 'number',
    label: 'Protagonist Head Defeat Aspect Ratio',
    group: 'ASSETS',
  },
  assetEnemyLaptopAspectRatio: {
    value: 0.8697,
    type: 'number',
    label: 'Enemy Laptop Aspect Ratio',
    group: 'ASSETS',
  },
  assetEnemyEmailAspectRatio: {
    value: 1.1266,
    type: 'number',
    label: 'Enemy Email Aspect Ratio',
    group: 'ASSETS',
  },
  assetEnemyTasklistAspectRatio: {
    value: 0.6696,
    type: 'number',
    label: 'Enemy Tasklist Aspect Ratio',
    group: 'ASSETS',
  },
  assetEnemyDeadlineAspectRatio: {
    value: 0.9102,
    type: 'number',
    label: 'Enemy Deadline Aspect Ratio',
    group: 'ASSETS',
  },
  assetEnemyVulnerableAspectRatio: {
    value: 1.0,
    type: 'number',
    label: 'Enemy Vulnerable Aspect Ratio',
    group: 'ASSETS',
  },
  assetItemMateAspectRatio: {
    value: 0.9449,
    type: 'number',
    label: 'Mate Item Aspect Ratio',
    group: 'ASSETS',
  },
  assetItemThermosAspectRatio: {
    value: 0.5186,
    type: 'number',
    label: 'Thermos Item Aspect Ratio',
    group: 'ASSETS',
  },
  assetLifeIconAspectRatio: {
    value: 0.9810,
    type: 'number',
    label: 'Life Icon Aspect Ratio',
    group: 'ASSETS',
  },

  // Compatibility key
  playerSprite: {
    value: undefined as SpriteConfig | undefined,
    type: 'sprite',
    label: 'Player Sprite',
    group: 'Visuals',
  },
};

// Merge customized config values if present (injected by Playground)
const {playgroundConfig} = globalThis as {
  playgroundConfig?: Record<string, unknown>;
};
if (playgroundConfig) {
  for (const [key, value] of Object.entries(playgroundConfig)) {
    if (key in CONFIG) {
      Object.assign(CONFIG[key as keyof typeof CONFIG], {value});
    }
  }
}

/**
 * Type helper for reading values in game code
 */
export type ConfigKey = keyof typeof CONFIG;

/**
 * Gets a configuration value by key.
 * @param key The configuration key.
 * @return The configuration value.
 */
export function getConfig<K extends ConfigKey>(
  key: K,
): (typeof CONFIG)[K]['value'] {
  return CONFIG[key].value;
}
