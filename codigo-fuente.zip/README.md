# Ayuda a Juampi a escapar del laburo

Juego arcade de laberinto: juntá mates, usá los termos y escapá de los enemigos del trabajo.

## Desarrollo

Requiere Node.js 22.12 o posterior.

```sh
npm install
npm run dev
```

## Publicación

```sh
npm run build
```

La carpeta `dist` contiene el juego listo para un hosting estático. Las rutas son relativas, compatibles con GitHub Pages.

Controles: flechas o WASD; en celulares, botones en pantalla. Las instrucciones completas están dentro del juego.

Exportado de Google Playground y adaptado para ejecutarse de forma independiente. Ver `THIRD_PARTY_NOTICES.md`.
