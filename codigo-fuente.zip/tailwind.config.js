export default {content:['./index.html','./App.tsx','./utils/**/*.{ts,tsx}'],theme:{extend:{}},plugins:[]};
