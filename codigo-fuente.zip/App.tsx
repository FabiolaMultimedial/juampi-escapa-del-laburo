// tslint:disable
/* eslint-disable */
import {
  AlertTriangle,
  Flame,
  Heart,
  HelpCircle,
  Menu,
  Pause,
  Play,
  RotateCw,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {CONFIG, getConfig, THEME} from './constants';
import BackgroundMusic from './utils/BackgroundMusic';
import {
  createFixedStepper,
  drawAsset,
  gameAudio,
  GameState,
  MenuOverlay,
  prepareCanvas,
  useAssets,
  useAutoFocus,
  useInput,
  useIsMobile,
} from './utils/helper';
import {
  usePlayground,
  usePlaygroundGameLifecycle,
  useRpc,
} from './utils/usePlayground';

const BGM_PATH = 'assets/audio/bgm_arcade_chase.mp3';

// 21 columns x 22 rows arcade maze map definition
// 1 = Wall, 0 = Mate dot, 2 = Thermos power pellet, 3 = Empty corridor / Spawn box
const MAZE_MAP: number[][] = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
  [1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
  [1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 0, 1, 1, 1, 3, 1, 3, 1, 1, 1, 0, 1, 1, 1, 1, 1],
  [3, 3, 3, 3, 1, 0, 1, 3, 3, 3, 3, 3, 3, 3, 1, 0, 1, 3, 3, 3, 3],
  [1, 1, 1, 1, 1, 0, 1, 3, 1, 1, 3, 1, 1, 3, 1, 0, 1, 1, 1, 1, 1],
  [3, 3, 3, 3, 3, 0, 3, 3, 1, 3, 3, 3, 1, 3, 3, 0, 3, 3, 3, 3, 3],
  [1, 1, 1, 1, 1, 0, 1, 3, 1, 1, 1, 1, 1, 3, 1, 0, 1, 1, 1, 1, 1],
  [3, 3, 3, 3, 1, 0, 1, 3, 3, 3, 3, 3, 3, 3, 1, 0, 1, 3, 3, 3, 3],
  [1, 1, 1, 1, 1, 0, 1, 3, 1, 1, 1, 1, 1, 3, 1, 0, 1, 1, 1, 1, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1],
  [1, 2, 0, 0, 1, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1, 0, 0, 2, 1],
  [1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1],
  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

const COLS = 21;
const ROWS = 22;
const CELL_SIZE = 36;
const OFFSET_Y = 36;

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'NONE';

type EnemyTypeId =
  | 'laptop'
  | 'email'
  | 'clock'
  | 'checklist'
  | 'smartphone'
  | 'calendar'
  | 'document'
  | 'alarm';

interface EnemyDef {
  id: string;
  type: EnemyTypeId;
  name: string;
  spawnCol: number;
  spawnRow: number;
  spawnTime: number; // Wave unlock time in seconds (0, 0, 0, 0, 0, 15, 30, 45)
  color: string;
  speedMult: number;
  assetKey?: string;
}

const ENEMY_ROSTER: EnemyDef[] = [
  {
    id: 'e_laptop',
    type: 'laptop',
    name: 'Notebook Boss',
    spawnCol: 10,
    spawnRow: 8,
    spawnTime: 0,
    color: '#38bdf8',
    speedMult: 1.0,
    assetKey: 'enemy_laptop',
  },
  {
    id: 'e_email',
    type: 'email',
    name: 'Email Urgente',
    spawnCol: 9,
    spawnRow: 10,
    spawnTime: 0,
    color: '#ef4444',
    speedMult: 1.02,
    assetKey: 'enemy_email',
  },
  {
    id: 'e_clock',
    type: 'clock',
    name: 'Deadline 5PM',
    spawnCol: 11,
    spawnRow: 10,
    spawnTime: 0,
    color: '#ec4899',
    speedMult: 1.18,
    assetKey: 'enemy_deadline',
  },
  {
    id: 'e_checklist',
    type: 'checklist',
    name: 'Tareas Pendientes',
    spawnCol: 10,
    spawnRow: 10,
    spawnTime: 0,
    color: '#f97316',
    speedMult: 0.98,
    assetKey: 'enemy_tasklist',
  },
  {
    id: 'e_smartphone',
    type: 'smartphone',
    name: 'WhatsApp Laburo',
    spawnCol: 10,
    spawnRow: 12,
    spawnTime: 0,
    color: '#22c55e',
    speedMult: 1.05,
  },
  {
    id: 'e_calendar',
    type: 'calendar',
    name: 'Reunión 8:00 AM',
    spawnCol: 9,
    spawnRow: 12,
    spawnTime: 15,
    color: '#8b5cf6',
    speedMult: 1.0,
  },
  {
    id: 'e_document',
    type: 'document',
    name: 'Excel Corrupto',
    spawnCol: 11,
    spawnRow: 12,
    spawnTime: 30,
    color: '#eab308',
    speedMult: 1.04,
  },
  {
    id: 'e_alarm',
    type: 'alarm',
    name: 'Alarma de Guardia',
    spawnCol: 10,
    spawnRow: 10,
    spawnTime: 45,
    color: '#f43f5e',
    speedMult: 1.15,
  },
];

interface EnemyInstance {
  def: EnemyDef;
  x: number;
  y: number;
  dir: Direction;
  isSpawned: boolean;
  isVulnerable: boolean;
  isEaten: boolean;
  targetCol: number;
  targetRow: number;
  animTimer: number;
}

interface FloatingScore {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
  size: number;
}

// Check grid walkability
function isWalkable(c: number, r: number, grid: number[][]): boolean {
  if (r < 0 || r >= ROWS) return false;
  // Tunnel wrap columns are walkable
  if (c < 0 || c >= COLS) return r === 8 || r === 10 || r === 12;
  const cell = grid[r]?.[c];
  return cell !== 1;
}

// 4-directional moves
const DIRS: {dir: Direction; dc: number; dr: number}[] = [
  {dir: 'UP', dc: 0, dr: -1},
  {dir: 'DOWN', dc: 0, dr: 1},
  {dir: 'LEFT', dc: -1, dr: 0},
  {dir: 'RIGHT', dc: 1, dr: 0},
];

const OPPOSITE_DIR: Record<Direction, Direction> = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
  NONE: 'NONE',
};

// BFS Shortest Path to find the optimal next direction towards target tile
function getBfsNextDirection(
  startC: number,
  startR: number,
  targetC: number,
  targetR: number,
  currentDir: Direction,
  grid: number[][],
  allowReverse = false,
): Direction {
  // Clamp target
  const clampedTargetC = Math.max(0, Math.min(COLS - 1, targetC));
  const clampedTargetR = Math.max(0, Math.min(ROWS - 1, targetR));

  // If already at target, stay or pick open path
  if (startC === clampedTargetC && startR === clampedTargetR) {
    for (const d of DIRS) {
      if (
        (allowReverse || d.dir !== OPPOSITE_DIR[currentDir]) &&
        isWalkable(startC + d.dc, startR + d.dr, grid)
      ) {
        return d.dir;
      }
    }
    return currentDir;
  }

  // Queue stores [col, row, firstDir]
  const visited: boolean[][] = Array.from({length: ROWS}, () =>
    Array(COLS).fill(false),
  );
  if (startR >= 0 && startR < ROWS && startC >= 0 && startC < COLS) {
    visited[startR][startC] = true;
  }

  const queue: [number, number, Direction][] = [];

  // Initialize queue with valid immediate moves from start
  for (const d of DIRS) {
    const nextC = (startC + d.dc + COLS) % COLS;
    const nextR = startR + d.dr;

    if (!allowReverse && currentDir !== 'NONE' && d.dir === OPPOSITE_DIR[currentDir]) {
      continue;
    }

    if (isWalkable(nextC, nextR, grid)) {
      if (nextC === clampedTargetC && nextR === clampedTargetR) {
        return d.dir;
      }
      if (nextR >= 0 && nextR < ROWS && !visited[nextR][nextC]) {
        visited[nextR][nextC] = true;
        queue.push([nextC, nextR, d.dir]);
      }
    }
  }

  // If no forward move was possible, allow reverse
  if (queue.length === 0 && currentDir !== 'NONE') {
    const opp = OPPOSITE_DIR[currentDir];
    const oppD = DIRS.find((d) => d.dir === opp);
    if (oppD && isWalkable((startC + oppD.dc + COLS) % COLS, startR + oppD.dr, grid)) {
      return opp;
    }
  }

  let head = 0;
  while (head < queue.length) {
    const [c, r, firstDir] = queue[head++];
    if (c === clampedTargetC && r === clampedTargetR) {
      return firstDir;
    }

    for (const d of DIRS) {
      const nc = (c + d.dc + COLS) % COLS;
      const nr = r + d.dr;

      if (nr >= 0 && nr < ROWS && !visited[nr][nc] && isWalkable(nc, nr, grid)) {
        visited[nr][nc] = true;
        queue.push([nc, nr, firstDir]);
      }
    }
  }

  // Fallback: pick any walkable direction
  for (const d of DIRS) {
    if (
      (allowReverse || d.dir !== OPPOSITE_DIR[currentDir]) &&
      isWalkable(startC + d.dc, startR + d.dr, grid)
    ) {
      return d.dir;
    }
  }

  return currentDir !== 'NONE' ? currentDir : 'UP';
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stepperRef = useRef<ReturnType<typeof createFixedStepper>>();
  const isMobile = useIsMobile();

  const lastCancelRef = useRef(false);
  const {sdk, isReady} = usePlayground();
  const [exitChat] = useRpc<Record<string, unknown>, void>('ExitChat');

  const ASSETS_MANIFEST: Record<string, string> = {
    protagonist_head: 'assets/images/protagonist_head.png',
    protagonist_head_eat: 'assets/images/protagonist_head_eat.png',
    protagonist_head_defeat: 'assets/images/protagonist_head_defeat.png',
    enemy_laptop: 'assets/images/enemy_laptop.png',
    enemy_email: 'assets/images/enemy_email.png',
    enemy_tasklist: 'assets/images/enemy_tasklist.png',
    enemy_deadline: 'assets/images/enemy_deadline.png',
    enemy_vulnerable: 'assets/images/enemy_vulnerable.png',
    item_mate: 'assets/images/item_mate.png',
    item_thermos: 'assets/images/item_thermos.png',
    life_icon: 'assets/images/life_icon.png',
  };

  const {assets, isReady: assetsReady} = useAssets(ASSETS_MANIFEST);

  const canvasWidth = getConfig('baseCanvasWidth') as number;
  const canvasHeight = getConfig('baseCanvasHeight') as number;

  if (!stepperRef.current) {
    const stepMs = getConfig('stepMs');
    const maxSubSteps = getConfig('maxSubSteps');
    stepperRef.current = createFixedStepper(stepMs, maxSubSteps);
  }

  const [gameState, setGameState] = useState<GameState>({
    status: 'START',
    score: 0,
    level: 1,
    lives: getConfig('startingLives') as number,
  });

  const [highScore, setHighScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('escape_laburo_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });

  const [isGameMenuOpen, setIsGameMenuOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isMusicMuted, setIsMusicMuted] = useState(false);
  const [isSfxMuted, setIsSfxMuted] = useState(false);

  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  useEffect(() => {
    document.title = 'Ayuda a Juampi a escapar del laburo';
  }, []);

  useEffect(() => {
    (window as any).canHandleBackKey = gameState.status !== 'START';
  }, [gameState.status]);

  const inputRef = useInput(canvasRef, true, {
    width: canvasWidth,
    height: canvasHeight,
  });

  // Dynamic simulation variables in refs
  const playerRef = useRef({
    x: 10 * CELL_SIZE + CELL_SIZE / 2,
    y: 16 * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
    dir: 'NONE' as Direction,
    nextDir: 'NONE' as Direction,
    isMouthOpen: false,
    mouthTimer: 0,
    deathPauseTimer: 0,
    invulnerableTimer: 2.0,
    history: [] as {c: number; r: number}[],
  });

  const dotsGridRef = useRef<number[][]>([]);
  const totalMatesRef = useRef(0);
  const matesLeftRef = useRef(0);

  const enemiesRef = useRef<EnemyInstance[]>([]);
  const gameTimeRef = useRef(0);
  const thermosTimerRef = useRef(0);
  const enemyStreakRef = useRef(0);
  const floatingScoresRef = useRef<FloatingScore[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const screenShakeRef = useRef(0);

  const touchStartPos = useRef<{x: number; y: number} | null>(null);

  // Sound effects tied to win/loss
  useEffect(() => {
    if (gameState.status === 'GAME_OVER') {
      gameAudio.playDefeatMotif();
    } else if (gameState.status === 'VICTORY') {
      gameAudio.playVictoryFanfare();
    }
  }, [gameState.status]);

  const createEnemiesList = (): EnemyInstance[] => {
    return ENEMY_ROSTER.map((def) => ({
      def,
      x: def.spawnCol * CELL_SIZE + CELL_SIZE / 2,
      y: def.spawnRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
      dir: 'UP',
      isSpawned: def.spawnTime === 0,
      isVulnerable: false,
      isEaten: false,
      targetCol: 10,
      targetRow: 8,
      animTimer: Math.random() * 10,
    }));
  };

  const resetEntitiesOnDeath = () => {
    const p = playerRef.current;
    p.x = 10 * CELL_SIZE + CELL_SIZE / 2;
    p.y = 16 * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y;
    p.dir = 'NONE';
    p.nextDir = 'NONE';
    p.invulnerableTimer = 2.0;
    p.deathPauseTimer = 0.8; // 800ms pause & shake
    p.history = [{c: 10, r: 16}];

    // Reset enemies back to spawn points without un-spawning wave unlocked ones
    enemiesRef.current.forEach((e) => {
      e.x = e.def.spawnCol * CELL_SIZE + CELL_SIZE / 2;
      e.y = e.def.spawnRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y;
      e.dir = 'UP';
      e.isEaten = false;
      e.isVulnerable = thermosTimerRef.current > 0;
    });
  };

  const initGame = useCallback((level = 1, currentScore = 0, currentLives = 3) => {
    // Clone initial maze dots
    let dots = 0;
    const grid: number[][] = [];
    for (let r = 0; r < ROWS; r++) {
      grid[r] = [];
      for (let c = 0; c < COLS; c++) {
        const cell = MAZE_MAP[r]?.[c] ?? 1;
        grid[r][c] = cell;
        if (cell === 0 || cell === 2) {
          dots++;
        }
      }
    }
    dotsGridRef.current = grid;
    totalMatesRef.current = dots;
    matesLeftRef.current = dots;

    playerRef.current = {
      x: 10 * CELL_SIZE + CELL_SIZE / 2,
      y: 16 * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
      dir: 'NONE',
      nextDir: 'NONE',
      isMouthOpen: false,
      mouthTimer: 0,
      deathPauseTimer: 0,
      invulnerableTimer: 2.0,
      history: [{c: 10, r: 16}],
    };

    gameTimeRef.current = 0;
    thermosTimerRef.current = 0;
    enemyStreakRef.current = 0;
    floatingScoresRef.current = [];
    particlesRef.current = [];
    screenShakeRef.current = 0;

    enemiesRef.current = createEnemiesList();

    setGameState({
      status: 'PLAYING',
      score: currentScore,
      level,
      lives: currentLives,
    });
    setIsGameMenuOpen(false);
    setIsHowToPlayOpen(false);

    if (sdk) {
      sdk.startGame();
    }
    gameAudio.playConfirmSelect();
  }, [sdk]);

  usePlaygroundGameLifecycle(gameState, sdk);

  // Autoplay handler
  const hasAutoplayed = useRef(false);
  useEffect(() => {
    if (
      !hasAutoplayed.current &&
      new URLSearchParams(window.location.search).has('autoplay')
    ) {
      hasAutoplayed.current = true;
      initGame();
    }
  }, [initGame]);

  const canMoveInDirection = (
    currX: number,
    currY: number,
    dir: Direction,
  ): boolean => {
    if (dir === 'NONE') return true;
    const col = Math.floor(currX / CELL_SIZE);
    const row = Math.floor((currY - OFFSET_Y) / CELL_SIZE);

    let targetCol = col;
    let targetRow = row;

    if (dir === 'UP') targetRow--;
    if (dir === 'DOWN') targetRow++;
    if (dir === 'LEFT') targetCol--;
    if (dir === 'RIGHT') targetCol++;

    return isWalkable(targetCol, targetRow, dotsGridRef.current);
  };

  const triggerDirection = (newDir: Direction) => {
    playerRef.current.nextDir = newDir;
    gameAudio.playHoverMicroTone();
  };

  const spawnParticles = (x: number, y: number, color: string, count = 12) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 120;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        life: 0.4 + Math.random() * 0.3,
        size: 3 + Math.random() * 3,
      });
    }
  };

  const spawnFloatingScore = (x: number, y: number, text: string, color = '#fbbf24') => {
    floatingScoresRef.current.push({
      id: Date.now() + Math.random(),
      x,
      y,
      text,
      color,
      life: 0.9,
    });
  };

  const update = (dt: number) => {
    if (gameState.status !== 'PLAYING' || isGameMenuOpen || isHowToPlayOpen) return;

    const p = playerRef.current;

    // Handle Death Pause timer
    if (p.deathPauseTimer > 0) {
      p.deathPauseTimer = Math.max(0, p.deathPauseTimer - dt);
      return;
    }

    gameTimeRef.current += dt;

    // Progressive Wave Spawning: Check if any new enemies unlock
    enemiesRef.current.forEach((e) => {
      if (!e.isSpawned && gameTimeRef.current >= e.def.spawnTime) {
        e.isSpawned = true;
        spawnParticles(e.x, e.y, e.def.color, 15);
        spawnFloatingScore(e.x, e.y, `¡${e.def.name}!`, e.def.color);
        gameAudio.playHoverMicroTone();
      }
    });

    // Handle Input & Direction Buffering
    const actions = inputRef.current.actions;
    if (actions.up) p.nextDir = 'UP';
    else if (actions.down) p.nextDir = 'DOWN';
    else if (actions.left) p.nextDir = 'LEFT';
    else if (actions.right) p.nextDir = 'RIGHT';

    const basePlayerSpeed = getConfig('playerSpeed') as number;
    const baseEnemySpeed = (getConfig('enemyNormalSpeed') as number) * (1 + (gameState.level - 1) * 0.08);
    const enemyVulnSpeed = getConfig('enemyVulnerableSpeed') as number;
    const matePts = getConfig('matePoints') as number;
    const thermosPts = getConfig('thermosPoints') as number;

    if (p.invulnerableTimer > 0) {
      p.invulnerableTimer = Math.max(0, p.invulnerableTimer - dt);
    }

    if (thermosTimerRef.current > 0) {
      thermosTimerRef.current = Math.max(0, thermosTimerRef.current - dt);
      if (thermosTimerRef.current === 0) {
        enemiesRef.current.forEach((e) => {
          e.isVulnerable = false;
        });
      }
    }

    // Screen Shake decay
    if (screenShakeRef.current > 0) {
      screenShakeRef.current = Math.max(0, screenShakeRef.current - dt * 15);
    }

    // --- Player Movement with Center-Corridor Snapping ---
    const pCol = Math.floor(p.x / CELL_SIZE);
    const pRow = Math.floor((p.y - OFFSET_Y) / CELL_SIZE);
    const currentCenterColX = pCol * CELL_SIZE + CELL_SIZE / 2;
    const currentCenterRowY = pRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y;

    // Track Player tile history for trail-chasers (Document hazard)
    const lastTile = p.history[p.history.length - 1];
    if (!lastTile || lastTile.c !== pCol || lastTile.r !== pRow) {
      p.history.push({c: pCol, r: pRow});
      if (p.history.length > 20) p.history.shift();
    }

    // Turn queuing
    if (p.nextDir !== 'NONE' && p.nextDir !== p.dir) {
      const isOpposite =
        (p.dir === 'UP' && p.nextDir === 'DOWN') ||
        (p.dir === 'DOWN' && p.nextDir === 'UP') ||
        (p.dir === 'LEFT' && p.nextDir === 'RIGHT') ||
        (p.dir === 'RIGHT' && p.nextDir === 'LEFT');

      if (isOpposite) {
        p.dir = p.nextDir;
      } else {
        const alignDistX = Math.abs(p.x - currentCenterColX);
        const alignDistY = Math.abs(p.y - currentCenterRowY);
        const tolerance = 12;

        if (alignDistX <= tolerance && alignDistY <= tolerance) {
          if (canMoveInDirection(currentCenterColX, currentCenterRowY, p.nextDir)) {
            p.x = currentCenterColX;
            p.y = currentCenterRowY;
            p.dir = p.nextDir;
          }
        }
      }
    }

    // Move player in current direction
    if (p.dir !== 'NONE') {
      let vx = 0;
      let vy = 0;
      if (p.dir === 'UP') vy = -basePlayerSpeed;
      if (p.dir === 'DOWN') vy = basePlayerSpeed;
      if (p.dir === 'LEFT') vx = -basePlayerSpeed;
      if (p.dir === 'RIGHT') vx = basePlayerSpeed;

      const nextX = p.x + vx * dt;
      const nextY = p.y + vy * dt;

      // Handle lateral warp tunnels (wrap left/right)
      if (nextX < -CELL_SIZE / 2) {
        p.x = canvasWidth + CELL_SIZE / 2;
      } else if (nextX > canvasWidth + CELL_SIZE / 2) {
        p.x = -CELL_SIZE / 2;
      } else {
        const testCol = Math.floor((nextX + (vx > 0 ? 14 : -14)) / CELL_SIZE);
        const testRow = Math.floor((nextY - OFFSET_Y + (vy > 0 ? 14 : -14)) / CELL_SIZE);

        const isWall = dotsGridRef.current[testRow]?.[testCol] === 1;
        if (!isWall) {
          p.x = nextX;
          p.y = nextY;
        } else {
          // Snap to corridor center and stop
          if (p.dir === 'UP' || p.dir === 'DOWN') p.y = currentCenterRowY;
          if (p.dir === 'LEFT' || p.dir === 'RIGHT') p.x = currentCenterColX;
          p.dir = 'NONE';
        }
      }

      // Mouth animation
      p.mouthTimer += dt;
      if (p.mouthTimer > 0.12) {
        p.mouthTimer = 0;
        p.isMouthOpen = !p.isMouthOpen;
      }
    }

    // --- Collect Items (Mate / Thermos) ---
    if (
      pRow >= 0 &&
      pRow < ROWS &&
      pCol >= 0 &&
      pCol < COLS &&
      dotsGridRef.current[pRow]
    ) {
      const cellVal = dotsGridRef.current[pRow][pCol];
      if (cellVal === 0) {
        // Mate dot collected
        dotsGridRef.current[pRow][pCol] = 3;
        matesLeftRef.current = Math.max(0, matesLeftRef.current - 1);
        gameAudio.playPotionGulp();
        spawnParticles(
          pCol * CELL_SIZE + CELL_SIZE / 2,
          pRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
          '#22c55e',
          5,
        );

        setGameState((prev) => {
          const newScore = prev.score + matePts;
          if (newScore > highScore) {
            setHighScore(newScore);
            try {
              localStorage.setItem('escape_laburo_highscore', newScore.toString());
            } catch {}
          }
          return {...prev, score: newScore};
        });
      } else if (cellVal === 2) {
        // Power Thermos collected!
        dotsGridRef.current[pRow][pCol] = 3;
        matesLeftRef.current = Math.max(0, matesLeftRef.current - 1);
        thermosTimerRef.current = getConfig('thermosDuration') as number;
        enemyStreakRef.current = 0;
        screenShakeRef.current = 5;
        gameAudio.playPowerupChime();

        spawnParticles(
          pCol * CELL_SIZE + CELL_SIZE / 2,
          pRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
          '#ef4444',
          20,
        );
        spawnFloatingScore(
          pCol * CELL_SIZE + CELL_SIZE / 2,
          pRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y,
          `+${thermosPts} TERMO!`,
          '#f43f5e',
        );

        enemiesRef.current.forEach((e) => {
          if (!e.isEaten && e.isSpawned) {
            e.isVulnerable = true;
          }
        });

        setGameState((prev) => {
          const newScore = prev.score + thermosPts;
          if (newScore > highScore) {
            setHighScore(newScore);
            try {
              localStorage.setItem('escape_laburo_highscore', newScore.toString());
            } catch {}
          }
          return {...prev, score: newScore};
        });
      }

      // Check Level Victory Condition
      if (matesLeftRef.current <= 0) {
        gameAudio.playVictoryFanfare();
        // Advance to next level or win
        const nextLvl = gameState.level + 1;
        spawnFloatingScore(canvasWidth / 2, canvasHeight / 2, `¡NIVEL ${nextLvl}!`, '#22c55e');
        setTimeout(() => {
          initGame(nextLvl, gameState.score + 500, gameState.lives);
        }, 1200);
        return;
      }
    }

    // --- Update 8 Distinct Enemy Behaviors & BFS Grid Movement ---
    enemiesRef.current.forEach((e) => {
      if (!e.isSpawned) return;
      e.animTimer += dt;

      const speed = e.isEaten
        ? 240
        : e.isVulnerable
        ? enemyVulnSpeed
        : baseEnemySpeed * e.def.speedMult;

      // Handle Respawn return to home box if eaten
      if (e.isEaten) {
        const homeX = e.def.spawnCol * CELL_SIZE + CELL_SIZE / 2;
        const homeY = e.def.spawnRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y;
        const dx = homeX - e.x;
        const dy = homeY - e.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 10) {
          e.isEaten = false;
          e.isVulnerable = thermosTimerRef.current > 0;
          e.dir = 'UP';
          e.x = homeX;
          e.y = homeY;
        } else {
          e.x += (dx / dist) * speed * dt;
          e.y += (dy / dist) * speed * dt;
          return;
        }
      }

      // Current grid tile and exact tile center
      const eCol = Math.floor(e.x / CELL_SIZE);
      const eRow = Math.floor((e.y - OFFSET_Y) / CELL_SIZE);
      const eCenterX = eCol * CELL_SIZE + CELL_SIZE / 2;
      const eCenterY = eRow * CELL_SIZE + CELL_SIZE / 2 + OFFSET_Y;

      const distToCenter = Math.hypot(e.x - eCenterX, e.y - eCenterY);
      const stepDist = speed * dt;

      // Calculate Target Tile based on 8 unique AI personalities
      if (e.isVulnerable) {
        // Flee: Target the farthest corner from player
        const cornerC = pCol < COLS / 2 ? COLS - 2 : 1;
        const cornerR = pRow < ROWS / 2 ? ROWS - 2 : 1;
        e.targetCol = cornerC;
        e.targetRow = cornerR;
      } else {
        switch (e.def.type) {
          case 'laptop': // 1. Notebook Boss: Direct shortest BFS pursuer
            e.targetCol = pCol;
            e.targetRow = pRow;
            break;

          case 'email': { // 2. Email: Interceptor aiming 3-4 tiles ahead of player
            let aheadC = pCol;
            let aheadR = pRow;
            if (p.dir === 'UP') aheadR -= 4;
            if (p.dir === 'DOWN') aheadR += 4;
            if (p.dir === 'LEFT') aheadC -= 4;
            if (p.dir === 'RIGHT') aheadC += 4;
            e.targetCol = Math.max(1, Math.min(COLS - 2, aheadC));
            e.targetRow = Math.max(1, Math.min(ROWS - 2, aheadR));
            break;
          }

          case 'clock': { // 3. Deadline Clock: High speed sprint periodically chasing directly or sweeping perimeter
            const isSprintPhase = Math.floor(e.animTimer % 6) < 4;
            if (isSprintPhase) {
              e.targetCol = pCol;
              e.targetRow = pRow;
            } else {
              e.targetCol = pCol > COLS / 2 ? 1 : COLS - 2;
              e.targetRow = pRow > ROWS / 2 ? 1 : ROWS - 2;
            }
            break;
          }

          case 'checklist': { // 4. Task Checklist: Aggressive if <= 6 tiles, else patrols corridor perimeter
            const dist = Math.hypot(eCol - pCol, eRow - pRow);
            if (dist <= 6) {
              e.targetCol = pCol;
              e.targetRow = pRow;
            } else {
              e.targetCol = Math.floor(e.animTimer % 2) === 0 ? 1 : COLS - 2;
              e.targetRow = 1;
            }
            break;
          }

          case 'smartphone': { // 5. Smartphone: Erratic wanderer with sudden bursts
            if (Math.random() < 0.05 || e.targetCol === eCol) {
              const rCol = Math.floor(Math.random() * (COLS - 2)) + 1;
              const rRow = Math.floor(Math.random() * (ROWS - 2)) + 1;
              e.targetCol = rCol;
              e.targetRow = rRow;
            }
            break;
          }

          case 'calendar': { // 6. Calendar: Ambush blocker cutting off escape routes ahead
            let blockC = pCol;
            let blockR = pRow;
            if (p.dir === 'UP' || p.dir === 'DOWN') {
              blockC += pCol > COLS / 2 ? -3 : 3;
            } else {
              blockR += pRow > ROWS / 2 ? -3 : 3;
            }
            e.targetCol = Math.max(1, Math.min(COLS - 2, blockC));
            e.targetRow = Math.max(1, Math.min(ROWS - 2, blockR));
            break;
          }

          case 'document': { // 7. Document: Trail chaser targeting 2-3 tiles behind player path history
            const histIdx = Math.max(0, p.history.length - 4);
            const trail = p.history[histIdx] || {c: pCol, r: pRow};
            e.targetCol = trail.c;
            e.targetRow = trail.r;
            break;
          }

          case 'alarm': { // 8. Alarm: Hyperactive zig-zagger targeting player center with frequent flank turns
            const offset = (Math.sin(e.animTimer * 4) > 0 ? 2 : -2);
            e.targetCol = Math.max(1, Math.min(COLS - 2, pCol + offset));
            e.targetRow = Math.max(1, Math.min(ROWS - 2, pRow - offset));
            break;
          }
        }
      }

      // Check if enemy reached intersection center to pick next direction via BFS
      if (distToCenter <= Math.max(stepDist * 1.5, 3)) {
        const nextDir = getBfsNextDirection(
          eCol,
          eRow,
          e.targetCol,
          e.targetRow,
          e.dir,
          dotsGridRef.current,
          false,
        );

        e.dir = nextDir;
        // Snap along perpendicular axis for smooth alignment
        if (e.dir === 'UP' || e.dir === 'DOWN') e.x = eCenterX;
        if (e.dir === 'LEFT' || e.dir === 'RIGHT') e.y = eCenterY;
      }

      // Continuous movement in chosen direction
      if (e.dir === 'UP') e.y -= speed * dt;
      if (e.dir === 'DOWN') e.y += speed * dt;
      if (e.dir === 'LEFT') e.x -= speed * dt;
      if (e.dir === 'RIGHT') e.x += speed * dt;

      // Handle lateral tunnel warp
      if (e.x < -CELL_SIZE / 2) e.x = canvasWidth + CELL_SIZE / 2;
      if (e.x > canvasWidth + CELL_SIZE / 2) e.x = -CELL_SIZE / 2;

      // --- Precise Contact Collision with Player ---
      const contactDist = Math.hypot(p.x - e.x, p.y - e.y);
      if (contactDist < 26) {
        if (e.isVulnerable && !e.isEaten) {
          // Eat enemy
          e.isEaten = true;
          e.isVulnerable = false;
          enemyStreakRef.current++;
          const comboScore = Math.min(1600, Math.pow(2, enemyStreakRef.current) * 100); // 200, 400, 800, 1600
          gameAudio.playChiptuneExplosion();
          screenShakeRef.current = 6;
          spawnParticles(e.x, e.y, e.def.color, 24);
          spawnFloatingScore(e.x, e.y, `+${comboScore}!`, '#38bdf8');

          setGameState((prev) => {
            const newScore = prev.score + comboScore;
            if (newScore > highScore) {
              setHighScore(newScore);
              try {
                localStorage.setItem('escape_laburo_highscore', newScore.toString());
              } catch {}
            }
            return {...prev, score: newScore};
          });
        } else if (!e.isEaten && p.invulnerableTimer <= 0 && p.deathPauseTimer <= 0) {
          // Lethal contact: Lose 1 life, trigger shake, pause, position reset
          gameAudio.playGeneralDamage();
          screenShakeRef.current = 12;
          spawnParticles(p.x, p.y, '#ef4444', 30);
          spawnFloatingScore(p.x, p.y, '¡OUCH! -1 VIDA', '#ef4444');

          const nextLives = (gameState.lives ?? 3) - 1;
          if (nextLives <= 0) {
            setGameState((prev) => ({...prev, lives: 0, status: 'GAME_OVER'}));
          } else {
            setGameState((prev) => ({...prev, lives: nextLives}));
            resetEntitiesOnDeath();
          }
        }
      }
    });

    // Update floating score texts
    floatingScoresRef.current.forEach((fs) => {
      fs.y -= 28 * dt;
      fs.life -= dt;
    });
    floatingScoresRef.current = floatingScoresRef.current.filter((fs) => fs.life > 0);

    // Update particles
    particlesRef.current.forEach((pt) => {
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= dt;
    });
    particlesRef.current = particlesRef.current.filter((pt) => pt.life > 0);
  };

  const draw = (ctx: CanvasRenderingContext2D) => {
    prepareCanvas(ctx, canvasWidth, canvasHeight);

    ctx.save();

    // Screen shake
    if (screenShakeRef.current > 0) {
      const shakeAmt = screenShakeRef.current;
      ctx.translate((Math.random() - 0.5) * shakeAmt, (Math.random() - 0.5) * shakeAmt);
    }

    // Black Arcade Deep Background
    ctx.fillStyle = THEME.backgroundColor;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Draw Neon Maze Walls
    const wallColor = THEME.wallColor;
    const wallGlow = THEME.wallGlow;

    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = dotsGridRef.current[r]?.[c];
        const cellX = c * CELL_SIZE;
        const cellY = r * CELL_SIZE + OFFSET_Y;

        if (cell === 1) {
          // Neon Wall Tile with rounded inner glow
          ctx.fillStyle = THEME.wallInner;
          ctx.fillRect(cellX + 2, cellY + 2, CELL_SIZE - 4, CELL_SIZE - 4);

          ctx.strokeStyle = wallColor;
          ctx.lineWidth = 3;
          ctx.strokeRect(cellX + 2, cellY + 2, CELL_SIZE - 4, CELL_SIZE - 4);

          // Neon Accent corner
          ctx.fillStyle = wallGlow;
          ctx.fillRect(cellX + CELL_SIZE / 2 - 2, cellY + CELL_SIZE / 2 - 2, 4, 4);
        } else if (cell === 0) {
          // Mate Item Dot with proportional aspect ratio
          const mateImg = assets['item_mate'];
          const mateAspect = (getConfig('assetItemMateAspectRatio') as number) || 0.9449;
          const mateW = 20;
          const mateH = mateW / mateAspect;

          drawAsset(
            ctx,
            mateImg,
            cellX + CELL_SIZE / 2 - mateW / 2,
            cellY + CELL_SIZE / 2 - mateH / 2,
            mateW,
            mateH,
            (fallbackCtx) => {
              fallbackCtx.fillStyle = '#22c55e';
              fallbackCtx.beginPath();
              fallbackCtx.arc(
                cellX + CELL_SIZE / 2,
                cellY + CELL_SIZE / 2,
                4,
                0,
                Math.PI * 2,
              );
              fallbackCtx.fill();
            },
          );
        } else if (cell === 2) {
          // Thermos Power Item (Pulsing) with proportional aspect ratio
          const thermosImg = assets['item_thermos'];
          const thermosAspect = (getConfig('assetItemThermosAspectRatio') as number) || 0.5186;
          const pulse = Math.sin(Date.now() / 140) * 2;
          const w = 18 + pulse;
          const h = w / thermosAspect;

          // Glow halo
          ctx.save();
          ctx.shadowColor = '#ef4444';
          ctx.shadowBlur = 12;
          drawAsset(
            ctx,
            thermosImg,
            cellX + CELL_SIZE / 2 - w / 2,
            cellY + CELL_SIZE / 2 - h / 2,
            w,
            h,
            (fallbackCtx) => {
              fallbackCtx.fillStyle = '#ef4444';
              fallbackCtx.fillRect(
                cellX + CELL_SIZE / 2 - 8,
                cellY + CELL_SIZE / 2 - 14,
                16,
                28,
              );
            },
          );
          ctx.restore();
        }
      }
    }

    // Draw Particles
    particlesRef.current.forEach((pt) => {
      ctx.fillStyle = pt.color;
      ctx.globalAlpha = Math.max(0, pt.life * 2);
      ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
    });
    ctx.globalAlpha = 1.0;

    // Draw 8 Distinct Enemies (Using Asset if available or rich retro pixel art fallback)
    enemiesRef.current.forEach((e) => {
      if (!e.isSpawned) return;

      ctx.save();
      const enemyBaseW = 32;

      if (e.isEaten) {
        // Eaten eyes returning home
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(e.x - 5, e.y, 4, 0, Math.PI * 2);
        ctx.arc(e.x + 5, e.y, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.arc(e.x - 5, e.y, 2, 0, Math.PI * 2);
        ctx.arc(e.x + 5, e.y, 2, 0, Math.PI * 2);
        ctx.fill();
      } else if (e.isVulnerable) {
        // Weakened state
        const vulnImg = assets['enemy_vulnerable'];
        const isBlinking = thermosTimerRef.current < 2.5 && Math.floor(Date.now() / 140) % 2 === 0;

        ctx.shadowColor = isBlinking ? '#ffffff' : '#38bdf8';
        ctx.shadowBlur = 10;

        drawAsset(
          ctx,
          vulnImg,
          e.x - enemyBaseW / 2,
          e.y - enemyBaseW / 2,
          enemyBaseW,
          enemyBaseW,
          (fallbackCtx) => {
            fallbackCtx.fillStyle = isBlinking ? '#ffffff' : '#1e3a8a';
            fallbackCtx.fillRect(
              e.x - enemyBaseW / 2,
              e.y - enemyBaseW / 2,
              enemyBaseW,
              enemyBaseW,
            );
          },
        );
      } else {
        // Normal Aggressive State with Custom Distinct Pixel Art for all 8 hazards
        const eImg = e.def.assetKey ? assets[e.def.assetKey] : null;

        ctx.shadowColor = e.def.color;
        ctx.shadowBlur = 8;

        if (eImg && eImg.complete && eImg.naturalWidth > 0) {
          let aspect = 1.0;
          if (e.def.type === 'laptop') aspect = (getConfig('assetEnemyLaptopAspectRatio') as number) || 0.8697;
          if (e.def.type === 'email') aspect = (getConfig('assetEnemyEmailAspectRatio') as number) || 1.1266;
          if (e.def.type === 'clock') aspect = (getConfig('assetEnemyDeadlineAspectRatio') as number) || 0.9102;
          if (e.def.type === 'checklist') aspect = (getConfig('assetEnemyTasklistAspectRatio') as number) || 0.6696;

          const w = enemyBaseW;
          const h = w / aspect;
          ctx.drawImage(
            eImg,
            e.x - w / 2,
            e.y - h / 2,
            w,
            h,
          );
        } else {
          // Robust Pixel-Art Procedural Renderer for all 8 types
          ctx.translate(e.x, e.y);

          switch (e.def.type) {
            case 'laptop': {
              // Screen + Keyboard
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(-14, -12, 28, 18);
              ctx.fillStyle = '#38bdf8'; // Glowing Blue Screen
              ctx.fillRect(-12, -10, 24, 14);
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(-16, 6, 32, 6);
              // Angry red eyes on screen
              ctx.fillStyle = '#ef4444';
              ctx.fillRect(-8, -6, 4, 4);
              ctx.fillRect(4, -6, 4, 4);
              break;
            }
            case 'email': {
              // Envelope with urgent badge
              ctx.fillStyle = '#f8fafc';
              ctx.fillRect(-14, -10, 28, 20);
              ctx.strokeStyle = '#ef4444';
              ctx.lineWidth = 2;
              ctx.strokeRect(-14, -10, 28, 20);
              // Envelope flap lines
              ctx.beginPath();
              ctx.moveTo(-14, -10);
              ctx.lineTo(0, 2);
              ctx.lineTo(14, -10);
              ctx.stroke();
              // Exclamation mark
              ctx.fillStyle = '#ef4444';
              ctx.fillRect(-2, -6, 4, 6);
              ctx.fillRect(-2, 2, 4, 3);
              break;
            }
            case 'clock': {
              // Clock dial + ticking hands
              ctx.fillStyle = '#ec4899';
              ctx.beginPath();
              ctx.arc(0, 0, 14, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(0, 0, 11, 0, Math.PI * 2);
              ctx.fill();
              // Hands
              const handAngle = e.animTimer * 8;
              ctx.strokeStyle = '#1e1b4b';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.moveTo(0, 0);
              ctx.lineTo(Math.cos(handAngle) * 8, Math.sin(handAngle) * 8);
              ctx.stroke();
              break;
            }
            case 'checklist': {
              // Task checklist board
              ctx.fillStyle = '#fed7aa';
              ctx.fillRect(-12, -14, 24, 28);
              ctx.fillStyle = '#ea580c';
              ctx.fillRect(-8, -10, 4, 4);
              ctx.fillRect(-8, -2, 4, 4);
              ctx.fillRect(-8, 6, 4, 4);
              ctx.fillStyle = '#431407';
              ctx.fillRect(-2, -9, 10, 2);
              ctx.fillRect(-2, -1, 10, 2);
              ctx.fillRect(-2, 7, 10, 2);
              break;
            }
            case 'smartphone': {
              // Vibrating smartphone
              const vib = Math.sin(e.animTimer * 30) * 2;
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(-10 + vib, -15, 20, 30);
              ctx.fillStyle = '#22c55e'; // Green WhatsApp
              ctx.fillRect(-8 + vib, -11, 16, 22);
              ctx.fillStyle = '#ffffff';
              ctx.fillRect(-2 + vib, 12, 4, 2);
              break;
            }
            case 'calendar': {
              // Calendar sheet with red top header
              ctx.fillStyle = '#ffffff';
              ctx.fillRect(-13, -12, 26, 26);
              ctx.fillStyle = '#8b5cf6';
              ctx.fillRect(-13, -12, 26, 8);
              ctx.fillStyle = '#1e1b4b';
              ctx.font = 'bold 9px monospace';
              ctx.textAlign = 'center';
              ctx.fillText('8AM', 0, 8);
              break;
            }
            case 'document': {
              // Excel Sheet folded corner
              ctx.fillStyle = '#fef08a';
              ctx.fillRect(-12, -14, 24, 28);
              ctx.fillStyle = '#ca8a04';
              ctx.fillRect(-8, -8, 16, 3);
              ctx.fillRect(-8, -2, 16, 3);
              ctx.fillRect(-8, 4, 16, 3);
              // Stamp
              ctx.fillStyle = '#dc2626';
              ctx.font = 'bold 8px monospace';
              ctx.fillText('URG!', 0, 12);
              break;
            }
            case 'alarm': {
              // Ringing alarm bell
              const ring = Math.sin(e.animTimer * 20) * 3;
              ctx.fillStyle = '#f43f5e';
              ctx.beginPath();
              ctx.arc(0, 2, 12, Math.PI, 0, false);
              ctx.lineTo(12, 12);
              ctx.lineTo(-12, 12);
              ctx.closePath();
              ctx.fill();
              // Ringing top bell
              ctx.fillStyle = '#e11d48';
              ctx.fillRect(-4 + ring, -14, 8, 4);
              break;
            }
          }
        }
      }
      ctx.restore();
    });

    // Draw Player (Protagonist Head) with proportional aspect ratio
    const p = playerRef.current;
    const pWidth = 28;
    const headAspect = p.isMouthOpen
      ? ((getConfig('assetHeadEatAspectRatio') as number) || 0.8673)
      : ((getConfig('assetHeadAspectRatio') as number) || 0.7476);
    const pHeight = pWidth / headAspect;

    ctx.save();
    if (p.invulnerableTimer > 0 && Math.floor(Date.now() / 100) % 2 === 0) {
      ctx.globalAlpha = 0.4;
    }

    const headImg = p.isMouthOpen
      ? assets['protagonist_head_eat']
      : assets['protagonist_head'];

    // Face orientation
    ctx.translate(p.x, p.y);
    if (p.dir === 'LEFT') {
      ctx.scale(-1, 1);
    } else if (p.dir === 'UP') {
      ctx.rotate(-Math.PI / 16);
    } else if (p.dir === 'DOWN') {
      ctx.rotate(Math.PI / 16);
    }

    drawAsset(
      ctx,
      headImg,
      -pWidth / 2,
      -pHeight / 2,
      pWidth,
      pHeight,
      (fallbackCtx) => {
        fallbackCtx.fillStyle = '#fbbf24';
        fallbackCtx.beginPath();
        fallbackCtx.arc(0, 0, pWidth / 2, 0, Math.PI * 2);
        fallbackCtx.fill();
      },
    );
    ctx.restore();

    // Draw Floating Scores
    floatingScoresRef.current.forEach((fs) => {
      ctx.save();
      ctx.font = 'bold 12px "Press Start 2P", monospace';
      ctx.fillStyle = fs.color;
      ctx.shadowColor = '#000000';
      ctx.shadowBlur = 4;
      ctx.textAlign = 'center';
      ctx.fillText(fs.text, fs.x, fs.y);
      ctx.restore();
    });

    ctx.restore();
  };

  // Keep latest loop refs
  const updateRef = useRef(update);
  const drawRef = useRef(draw);
  updateRef.current = update;
  drawRef.current = draw;

  useEffect(() => {
    let raf = 0;
    const loop = (time: number) => {
      if (inputRef.current) {
        const cancelPressed = inputRef.current.actions.cancel;
        if (cancelPressed && !lastCancelRef.current) {
          const currentStatus = gameStateRef.current.status;
          if (currentStatus === 'PLAYING') {
            setIsGameMenuOpen((prev) => !prev);
          } else if (currentStatus === 'START') {
            void exitChat({});
          } else if (['GAME_OVER', 'VICTORY'].includes(currentStatus)) {
            setGameState((prev) => ({...prev, status: 'START'}));
          }
        }
        lastCancelRef.current = cancelPressed;
      }

      stepperRef.current?.(time, (dt) => updateRef.current(dt));

      const ctx = canvasRef.current?.getContext('2d');
      if (ctx) drawRef.current(ctx);

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [exitChat]);

  const isMusicPlaying =
    gameState.status === 'PLAYING' && !isGameMenuOpen && !isHowToPlayOpen;

  const startBtnRef = useAutoFocus<HTMLButtonElement>(gameState.status === 'START');

  // Count active spawned hazards
  const activeEnemiesCount = enemiesRef.current.filter((e) => e.isSpawned).length;

  return (
    <div className="fixed inset-0 overflow-hidden touch-none flex flex-col items-center justify-between bg-slate-950 text-white select-none font-mono">
      {!assetsReady && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white font-mono">
          <div className="text-xl animate-pulse text-yellow-400">
            CARGANDO RECURSOS...
          </div>
        </div>
      )}

      <BackgroundMusic
        url={BGM_PATH}
        isPlaying={isMusicPlaying}
        isMuted={isMusicMuted}
      />

      {/* Top Dedicated HUD Panel */}
      <header className="w-full bg-slate-900/90 border-b border-blue-900/50 px-3 py-2 z-10 shrink-0 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              Puntos
            </span>
            <span className="text-xs md:text-sm font-extrabold text-yellow-400">
              {gameState.score.toString().padStart(5, '0')}
            </span>
          </div>

          <div className="hidden sm:flex flex-col border-l border-slate-700 pl-3">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
              <Trophy size={10} className="text-amber-400" /> Récord
            </span>
            <span className="text-xs md:text-sm font-bold text-sky-300">
              {highScore.toString().padStart(5, '0')}
            </span>
          </div>

          <div className="hidden md:flex flex-col border-l border-slate-700 pl-3">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
              <Flame size={10} className="text-red-400" /> Peligros
            </span>
            <span className="text-xs font-bold text-red-300">
              {activeEnemiesCount}/8
            </span>
          </div>
        </div>

        <div className="text-center font-black tracking-wider text-[11px] md:text-sm text-sky-400 drop-shadow flex items-center gap-1">
          <span className="truncate max-w-[180px] sm:max-w-none">AYUDA A JUAMPI A ESCAPAR DEL LABURO</span>
          <span className="bg-blue-800 text-[10px] px-1.5 py-0.5 rounded text-blue-200 shrink-0">
            NIVEL {gameState.level}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Lives Mini Sprites */}
          <div className="flex items-center gap-1">
            {Array.from({length: Math.max(0, gameState.lives ?? 0)}).map((_, i) => (
              <img
                key={i}
                src={ASSETS_MANIFEST['life_icon']}
                alt="Vida"
                className="w-5 h-5 object-contain"
              />
            ))}
          </div>

          {/* Dedicated Top-Right Pause/Game Menu Button */}
          <button
            onClick={() => {
              gameAudio.playCrispClick();
              setIsGameMenuOpen(true);
            }}
            aria-label="Abrir Menú"
            className="bg-blue-600/80 hover:bg-blue-500 active:scale-95 text-white p-2 rounded-lg border border-blue-400/40 shadow flex items-center justify-center min-w-[48px] min-h-[48px]">
            <Menu size={18} />
          </button>
        </div>
      </header>

      {/* Canvas Wrapper */}
      <div
        className="flex-1 w-full min-h-0 relative flex items-center justify-center bg-black"
        onTouchStart={(e) => {
          if (e.touches[0]) {
            touchStartPos.current = {
              x: e.touches[0].clientX,
              y: e.touches[0].clientY,
            };
          }
        }}
        onTouchEnd={(e) => {
          if (!touchStartPos.current || !e.changedTouches[0]) return;
          const dx = e.changedTouches[0].clientX - touchStartPos.current.x;
          const dy = e.changedTouches[0].clientY - touchStartPos.current.y;
          const absX = Math.abs(dx);
          const absY = Math.abs(dy);
          const minSwipe = 20;

          if (Math.max(absX, absY) > minSwipe) {
            if (absX > absY) {
              triggerDirection(dx > 0 ? 'RIGHT' : 'LEFT');
            } else {
              triggerDirection(dy > 0 ? 'DOWN' : 'UP');
            }
          }
          touchStartPos.current = null;
        }}>
        <canvas
          ref={canvasRef}
          width={canvasWidth}
          height={canvasHeight}
          style={{
            aspectRatio: `${canvasWidth} / ${canvasHeight}`,
            width: `min(100%, calc(100vh * ${canvasWidth} / ${canvasHeight}))`,
          }}
          className="h-auto max-w-full max-h-full"
        />
      </div>

      {/* Mobile Touch D-Pad Overlay */}
      {isMobile && gameState.status === 'PLAYING' && (
        <div className="w-full bg-slate-900/90 border-t border-slate-800 p-2 flex items-center justify-center gap-6 z-20 shrink-0">
          <div className="grid grid-cols-3 gap-1.5 w-44 h-44 p-1">
            <div />
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                triggerDirection('UP');
              }}
              className="bg-slate-800 active:bg-blue-600 border-2 border-blue-500 rounded-xl flex items-center justify-center text-xl font-black min-w-[48px] min-h-[48px] shadow-lg">
              ▲
            </button>
            <div />

            <button
              onPointerDown={(e) => {
                e.preventDefault();
                triggerDirection('LEFT');
              }}
              className="bg-slate-800 active:bg-blue-600 border-2 border-blue-500 rounded-xl flex items-center justify-center text-xl font-black min-w-[48px] min-h-[48px] shadow-lg">
              ◀
            </button>
            <div className="flex items-center justify-center">
              <span className="text-[10px] text-slate-500 font-bold">D-PAD</span>
            </div>
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                triggerDirection('RIGHT');
              }}
              className="bg-slate-800 active:bg-blue-600 border-2 border-blue-500 rounded-xl flex items-center justify-center text-xl font-black min-w-[48px] min-h-[48px] shadow-lg">
              ▶
            </button>

            <div />
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                triggerDirection('DOWN');
              }}
              className="bg-slate-800 active:bg-blue-600 border-2 border-blue-500 rounded-xl flex items-center justify-center text-xl font-black min-w-[48px] min-h-[48px] shadow-lg">
              ▼
            </button>
            <div />
          </div>
        </div>
      )}

      {/* Start Game Menu Screen */}
      {gameState.status === 'START' && (
        <MenuOverlay tone="neutral" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900/95 border-2 border-blue-500 rounded-2xl p-6 flex flex-col items-center text-center shadow-2xl backdrop-blur-md">
            <div className="relative mb-4">
              <img
                src={ASSETS_MANIFEST['protagonist_head']}
                alt="Protagonista"
                className="w-24 h-24 object-contain animate-bounce"
              />
              <span className="absolute -bottom-2 -right-2 bg-emerald-500 text-black text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                Hora del Mate
              </span>
            </div>

            <h1 className="text-xl md:text-2xl font-black text-yellow-400 mb-2 tracking-wide uppercase">
              AYUDA A JUAMPI A ESCAPAR DEL LABURO
            </h1>
            <p className="text-xs md:text-sm text-sky-200 mb-6 leading-relaxed">
              ¡Ayuda a Juampi a esquivar los 8 peligros de oficina (Notebook, Emails, WhatsApp, Deadlines)! Recolecta todos los mates y usa el Termo para derrotarlos.
            </p>

            <div className="w-full space-y-3">
              <button
                ref={startBtnRef}
                autoFocus
                onClick={() => initGame(1, 0, getConfig('startingLives') as number)}
                className="w-full bg-yellow-400 hover:bg-yellow-300 active:scale-95 text-slate-950 font-black py-3 px-6 rounded-xl text-base md:text-lg flex items-center justify-center gap-2 shadow-lg transition-transform min-h-[48px]">
                <Play size={20} /> INICIAR JUEGO (ENTER)
              </button>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 active:scale-95 text-sky-300 font-bold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 border border-slate-700 min-h-[48px]">
                <HelpCircle size={18} /> ¿CÓMO JUGAR?
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* Persistent In-Game Game Menu Modal */}
      {isGameMenuOpen && (
        <MenuOverlay tone="neutral" zIndex={60}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-blue-500 rounded-2xl p-6 shadow-2xl flex flex-col items-center">
            <div className="text-center mb-6">
              <div className="text-xs text-sky-300 font-bold tracking-widest uppercase">
                AYUDA A JUAMPI A ESCAPAR DEL LABURO
              </div>
              <h2 className="text-2xl font-black text-yellow-400 uppercase tracking-wider">
                MENÚ DE PAUSA
              </h2>
            </div>

            <div className="w-full space-y-3 mb-6">
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGameMenuOpen(false);
                }}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 min-h-[48px]">
                <Play size={20} /> REANUDAR
              </button>

              <button
                onClick={() => {
                  gameAudio.playConfirmSelect();
                  initGame(gameState.level, gameState.score, gameState.lives);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 text-yellow-400 font-bold py-3 rounded-xl flex items-center justify-center gap-2 border border-slate-700 min-h-[48px]">
                <RotateCw size={18} /> REINICIAR NIVEL
              </button>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold py-3 rounded-xl flex items-center justify-center gap-2 border border-slate-700 min-h-[48px]">
                <HelpCircle size={18} /> ¿CÓMO JUGAR?
              </button>
            </div>

            {/* Audio Toggles Requirement */}
            <div className="w-full bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-around mb-6">
              <button
                onClick={() => {
                  const muted = gameAudio.toggleMute();
                  setIsSfxMuted(muted);
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg font-bold text-xs min-h-[48px] ${
                  isSfxMuted ? 'bg-red-900/60 text-red-200' : 'bg-emerald-900/60 text-emerald-200'
                }`}>
                {isSfxMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                SFX: {isSfxMuted ? 'OFF' : 'ON'}
              </button>

              <button
                onClick={() => {
                  setIsMusicMuted(!isMusicMuted);
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg font-bold text-xs min-h-[48px] ${
                  isMusicMuted ? 'bg-red-900/60 text-red-200' : 'bg-emerald-900/60 text-emerald-200'
                }`}>
                {isMusicMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                MÚSICA: {isMusicMuted ? 'OFF' : 'ON'}
              </button>
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsGameMenuOpen(false);
                setGameState((prev) => ({...prev, status: 'START'}));
              }}
              className="text-xs text-slate-400 hover:text-red-400 underline py-2 min-h-[48px] flex items-center">
              Salir al Menú Principal
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* How To Play Guide Modal */}
      {isHowToPlayOpen && (
        <MenuOverlay tone="neutral" zIndex={70}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500 rounded-2xl p-6 shadow-2xl text-left max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-lg font-black text-emerald-400 uppercase">
                ¿CÓMO JUGAR?
              </h3>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(false);
                }}
                className="text-slate-400 hover:text-white p-2 min-w-[48px] min-h-[48px] flex items-center justify-center">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed mb-6">
              <p>
                🧉 <strong className="text-yellow-400">Objetivo:</strong> Recolecta todos los mates del laberinto para terminar la jornada laboral y avanzar de nivel.
              </p>
              <p>
                💼 <strong className="text-red-400">8 Peligros de Oficina:</strong>
                <br />• 💻 <strong>Notebook Boss:</strong> Persecución directa implacable.
                <br />• ✉️ <strong>Email Urgente:</strong> Te intercepta 4 casillas adelante.
                <br />• ⏰ <strong>Deadline 5PM:</strong> Corre a súper velocidad (+18%).
                <br />• 📋 <strong>Checklist:</strong> Patrulla y te ataca a quemarropa (&le;6 casillas).
                <br />• 📱 <strong>WhatsApp:</strong> Movimientos erráticos y giros sorpresivos.
                <br />• 📅 <strong>Reunión 8AM:</strong> Bloquea tus rutas de escape (+15s).
                <br />• 📄 <strong>Excel Corrupto:</strong> Te sigue las huellas por detrás (+30s).
                <br />• 🚨 <strong>Alarma de Guardia:</strong> Zig-zag agresivo (+45s).
              </p>
              <p>
                ⚡ <strong className="text-sky-400">Termo de Poder:</strong> Al agarrar un termo, los enemigos huyen asustados. ¡Cómetelos para puntos combo (200, 400, 800, 1600)!
              </p>
              <p>
                🛡️ <strong className="text-emerald-400">Vidas e Invulnerabilidad:</strong> Cada golpe quita 1 vida y activa 2 segundos de inmunidad parpadeante.
              </p>
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsHowToPlayOpen(false);
              }}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl text-center min-h-[48px]">
              ¡ENTENDIDO! CERRAR
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* Game Over Screen */}
      {gameState.status === 'GAME_OVER' && (
        <MenuOverlay tone="danger" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-600 rounded-2xl p-6 flex flex-col items-center text-center shadow-2xl">
            <img
              src={ASSETS_MANIFEST['protagonist_head_defeat']}
              alt="Derrotado"
              className="w-20 h-20 object-contain mb-3"
            />
            <h1 className="text-xl md:text-2xl font-black text-red-500 mb-2 uppercase">
              ¡EL LABURO ATRAPÓ A JUAMPI!
            </h1>
            <p className="text-xs text-slate-300 mb-4">
              El estrés laboral atrapó a Juampi antes de terminar el mate.
            </p>

            <div className="bg-slate-950 px-6 py-3 rounded-xl border border-slate-800 mb-6">
              <span className="text-xs text-slate-400 font-bold uppercase">
                Puntaje Final
              </span>
              <div className="text-2xl font-black text-yellow-400">
                {gameState.score}
              </div>
            </div>

            <button
              autoFocus
              onClick={() => initGame(1, 0, getConfig('startingLives') as number)}
              className="w-full bg-red-600 hover:bg-red-500 active:scale-95 text-white font-black py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-lg min-h-[48px]">
              <RotateCw size={20} /> REINTENTAR (ENTER)
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* Victory Screen */}
      {gameState.status === 'VICTORY' && (
        <MenuOverlay tone="victory" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500 rounded-2xl p-6 flex flex-col items-center text-center shadow-2xl">
            <div className="flex gap-2 mb-3">
              <img
                src={ASSETS_MANIFEST['protagonist_head']}
                alt="Victoria"
                className="w-20 h-20 object-contain animate-bounce"
              />
              <img
                src={ASSETS_MANIFEST['item_mate']}
                alt="Mate"
                className="w-16 h-16 object-contain"
              />
            </div>
            <h1 className="text-xl md:text-2xl font-black text-emerald-400 mb-2 uppercase">
              ¡JUAMPI ESCAPÓ DEL LABURO!
            </h1>
            <p className="text-xs text-slate-300 mb-4">
              ¡Juampi terminó todos los mates y burló las 8 tareas! Ahora sí, a descansar.
            </p>

            <div className="bg-slate-950 px-6 py-3 rounded-xl border border-slate-800 mb-6">
              <span className="text-xs text-slate-400 font-bold uppercase">
                Puntaje Maestro
              </span>
              <div className="text-2xl font-black text-yellow-400">
                {gameState.score}
              </div>
            </div>

            <button
              autoFocus
              onClick={() => initGame(1, 0, getConfig('startingLives') as number)}
              className="w-full bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-black py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-lg min-h-[48px]">
              <RotateCw size={20} /> JUGAR DE NUEVO (ENTER)
            </button>
          </div>
        </MenuOverlay>
      )}
    </div>
  );
}
